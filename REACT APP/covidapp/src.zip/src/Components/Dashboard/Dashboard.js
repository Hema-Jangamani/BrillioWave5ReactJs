import React,{useEffect, useState} from 'react'
import CountryCard from '../card/CountryCard';

export default function Dashboard() {
    const [content, setContent] = useState([]);
    const [inputCountry, setInputCountry] = useState([]);
    useEffect(() => {
        setInputCountry(localStorage.getItem('searchValue'));
        console.log(inputCountry);
       fetch(`https://corona.lmao.ninja/v2/countries/${inputCountry}`)
       .then(res=>res.json())
       .then(data=>{
           console.log(data);
           // setContent(data);
           //inputCountry.push(data);
       });
    }, [localStorage])
    return (
        <div>
            {/* <div data-testid="one" className="container mt-3">
                <div data-testid="two" className="row">
                    {
                        content.map((country, i) =>
                            <CountryCard key={i}
                                flag={country.countryInfo.flag}
                                country={country.country}
                                cases={country.cases}
                                active={country.active}
                                deaths={country.deaths} />
                        )
                    }
                </div>
            </div> */}
            <h1>Hello World</h1>
        </div>
    )
}